package com.Zetcode;

public class Board {

}
