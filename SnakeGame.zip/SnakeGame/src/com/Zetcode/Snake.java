package com.Zetcode;

public class Snake {

}
